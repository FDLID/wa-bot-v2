const help = (prefix) => {
	return `┌──「 *FDL BOT WA* 」
│
├「 OWNER STATUS 」
│
├◪ *NAME: FDL*
├◪ *WA: 628990542731*
├◪ *YT: FDL GANZ*
│
├──「 *TENTANG BOT* 」
│
├◪ ${prefix}info
├◪ ${prefix}owner
├◪ ${prefix}donasi
├◪ ${prefix}blocklist
│
├──「 *SIMPLE MENU* 」
│
├◪ ${prefix}sticker
├◪ ${prefix}sticker nobg
├◪ ${prefix}toimg
├◪ ${prefix}ttp
├◪ ${prefix}tts
├◪ ${prefix}nulis
│
├──「 *DOWNLOADER* 」
│
├◪ ${prefix}tiktod
├◪ ${prefix}ytmp3
│
├──「 *MEME MENU* 」
│
├◪ ${prefix}meme
├◪ ${prefix}memeindo
│
├──「 *GRUP MENU* 」
│
├◪ ${prefix}admin
├◪ ${prefix}welcome [1/0]
├◪ ${prefix}add
├◪ ${prefix}kick
├◪ ${prefix}promote
├◪ ${prefix}demote
├◪ ${prefix}tagall
├◪ ${prefix}tagall2
├◪ ${prefix}tagall3
├◪ ${prefix}linkgrup
├◪ ${prefix}leave
├◪ ${prefix}simih [1/0]
│
├──「 *18+ MENU* 」
│
├◪ ${prefix}loli
├◪ ${prefix}nsfwloli
│
├──「 *OTHER MENU* 」
│
├◪ ${prefix}quotes
├◪ ${prefix}ssweb
├◪ ${prefix}simi
├◪ ${prefix}ocr
├◪ ${prefix}wait
├◪ ${prefix}tiktokstalk
├◪ ${prefix}hilih
├◪ ${prefix}ytstalk
│
├──「 *OWNER MENU* 」
│
├◪ ${prefix}setprefix
├◪ ${prefix}bc
├◪ ${prefix}clearall
├◪ ${prefix}clone
│
└──「 *FDL BOT* 」
`
}

exports.help = help
