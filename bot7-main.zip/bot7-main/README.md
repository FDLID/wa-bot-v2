pkg upgrade && pkg update

pkg install bash

pkg install git

git clone https://github.com/FDLBOT/bot7

cd bot7

bash install.sh

npm start
